package {packageName}.{moduleName}.api.config;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author ok1996
 */
@Configuration
@EnableFeignClients(basePackages = {"{packageName}.{moduleName}.api.feign"})
@ComponentScan(value = {"{packageName}.{moduleName}.api"})
public class {moduleNameCapitalized}ApiAutoConfiguration {
}
