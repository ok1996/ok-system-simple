package {packageName}.{moduleName}.service;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author ok1996
 */
@SpringBootApplication
public class {moduleNameCapitalized}ServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run({moduleNameCapitalized}ServiceApplication.class, args);
    }
}


