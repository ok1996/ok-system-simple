package {packageName}.{moduleName}.service.config;

import cn.iosd.starter.datasource.mybatis.MapperLocations;
import org.flywaydb.core.Flyway;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * 配置MapperScan、MapperLocations、Flyway、ComponentScan以及是否启用
 *
 * @author ok1996
 */
@Configuration
@MapperScan(basePackages = "{packageName}.{moduleName}.service.mapper")
@ComponentScan(value = {"{packageName}.{moduleName}.service"})
@ConditionalOnProperty(value = "simple.scan.service.enabled", havingValue = "true", matchIfMissing = true)
public class {moduleNameCapitalized}ServiceAutoConfiguration {

    @Bean
    public Flyway {moduleName}Flyway(DataSource dataSource) {
        Flyway flyway = Flyway.configure()
                .dataSource(dataSource)
                .locations("classpath:db/mysql/{moduleName}")
                .baselineOnMigrate(true)
                .table("{moduleName}_flyway_schema_history")
                .load();
        flyway.migrate();
        return flyway;
    }

    @Bean
    public MapperLocations {moduleName}MapperLocations() {
        return new MapperLocations("classpath*:/{packageDir}/{moduleName}/service/mapper/**/*Mapper.xml");
    }
}
